//
//  ViewController.swift
//  aging_ppl
//
//  Created by Katie  Lee on 7/7/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var names = ["George", "Betty", "Fran", "Alan", "Allison", "Eliz", "Katie", "Jae", "Jin", "Frank", "Olson", "Marie"]
    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func resetButtonPressed(_ sender: UIButton) {
        tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        cell.textLabel?.text = names[indexPath.row]
        cell.detailTextLabel?.text = "\(arc4random_uniform(100)) years old"        
        return cell
    }
}

