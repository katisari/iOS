//
//  OtherViewController.swift
//  madlibs
//
//  Created by Katie  Lee on 7/9/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class OtherViewController: UIViewController {

    @IBOutlet weak var adjLabel: UITextField!
    @IBOutlet weak var verb2Label: UITextField!
    @IBOutlet weak var verb1Label: UITextField!
    @IBOutlet weak var nounLabel: UITextField!
    
    var text: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func submitButtonPressed(_ sender: UIButton) {
        text = "We are having a perfectly \(adjLabel.text!) time now. Later we will \(verb1Label.text!) and \(verb2Label.text!) in the \(nounLabel.text!)."
        performSegue(withIdentifier: "unwindSegueToVC1", sender: self)
    }
}
