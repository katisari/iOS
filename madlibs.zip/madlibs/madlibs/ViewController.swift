//
//  ViewController.swift
//  madlibs
//
//  Created by Katie  Lee on 7/9/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var madlibLabel: UILabel!
    var output: String = "..."
    override func viewDidLoad() {
        super.viewDidLoad()
        madlibLabel.text = output
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func unwindToViewController(segue:UIStoryboardSegue) {
        let src = segue.source as! OtherViewController
        madlibLabel.text = src.text
    }


}

