//
//  ViewController.swift
//  tipster
//
//  Created by Katie  Lee on 7/5/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var numberLabel: UILabel!
    
    @IBOutlet weak var smallOptionLabel: UILabel!
    @IBOutlet weak var smallTaxLabel: UILabel!
    @IBOutlet weak var smallTotal: UILabel!
    
    @IBOutlet weak var medOptionLabel: UILabel!
    @IBOutlet weak var medTaxLabel: UILabel!
    @IBOutlet weak var medTotal: UILabel!
    
    @IBOutlet weak var largeOptionLabel: UILabel!
    @IBOutlet weak var largeTaxLabel: UILabel!
    @IBOutlet weak var largeTotal: UILabel!
    
    @IBOutlet weak var groupLabel: UILabel!
    
    var main_num = "0"
    var tip_val = 25
    var group_val = 1
    @IBAction func numPressedButton(_ sender: UIButton) {
        if main_num == "0" {
            main_num = sender.titleLabel!.text!
        }
        else{
            main_num += sender.titleLabel!.text!
        }
        updateUI()
        
    }
    
    @IBAction func clearButtonPressed(_ sender: UIButton) {
        main_num = "0"
        updateUI()
        
    }
    @IBAction func tipSlider(_ sender: UISlider) {
        sender.minimumValue = 5
        sender.maximumValue = 45
        tip_val = Int(sender.value)
        updateUI()
    }
    @IBAction func groupSlider(_ sender: UISlider) {
        
        group_val = Int(sender.value)
        updateUI()
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        
    }

    func updateUI(){
        numberLabel.text = main_num
        medOptionLabel.text = String(tip_val) + "%"
        smallOptionLabel.text = String(tip_val-5)
            + "%"
        largeOptionLabel.text = String(tip_val + 5) + "%"

        if let main_num_worked = Double(main_num) {
            print("worked")
            
            smallTaxLabel.text =  String(format:  "%.2f", ((Double(tip_val-5)/100) * main_num_worked)/Double(group_val))
            smallTotal.text = String(format:  "%.2f", ((Double(tip_val-5)/100) * main_num_worked + main_num_worked)/Double(group_val))
            medTaxLabel.text =  String(format:  "%.2f", ((Double(tip_val)/100) * main_num_worked)/Double(group_val))
            medTotal.text = String(format:  "%.2f", ((Double(tip_val)/100) * main_num_worked + main_num_worked)/Double(group_val))
            largeTaxLabel.text =  String(format:  "%.2f", ((Double(tip_val+5)/100) * main_num_worked)/Double(group_val))
            largeTotal.text = String(format:  "%.2f", ((Double(tip_val+5)/100) * main_num_worked + main_num_worked)/Double(group_val))
        }
        groupLabel.text = "Group Size: " + String(group_val)
        
    }


}

