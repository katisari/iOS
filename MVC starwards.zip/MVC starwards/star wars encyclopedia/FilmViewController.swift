//
//  FilmViewController.swift
//  star wars encyclopedia
//
//  Created by Katie  Lee on 7/16/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class FilmViewController: UITableViewController {
    var films: [NSDictionary] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        StarWarsModel.getAllPeople(url: "https://swapi.co/api/films/", completionHandler: { // passing what becomes "completionHandler" in the 'getAllPeople' function definition in StarWarsModel.swift
            data, response, error in
            do {
                // Try converting the JSON object to "Foundation Types" (NSDictionary, NSArray, NSString, etc.)
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
                    if let results = jsonResult["results"] as? [NSDictionary] {
                        self.films.append(contentsOf: results)
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
                    }
                }
            } catch {
                print("Something went wrong")
            }
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return films.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "filmCell", for: indexPath)
        cell.textLabel?.text = films[indexPath.row]["title"] as? String
        return cell
    }

}
