//
//  PeopleViewController.swift
//  star wars encyclopedia
//
//  Created by Katie  Lee on 7/16/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class PeopleViewController: UITableViewController {
    var people: [NSDictionary] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        StarWarsModel.getAllPeople(url: "http://swapi.co/api/people/", completionHandler: { // passing what becomes "completionHandler" in the 'getAllPeople' function definition in StarWarsModel.swift
            data, response, error in
            do {
                // Try converting the JSON object to "Foundation Types" (NSDictionary, NSArray, NSString, etc.)
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
                    if let results = jsonResult["results"] as? [NSDictionary] {
                        self.people.append(contentsOf: results)
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
                    }
                }
            } catch {
                print("Something went wrong")
            }
        })
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return people.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = people[indexPath.row]["name"] as? String
        return cell
    }

}
