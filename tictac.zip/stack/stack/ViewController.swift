//
//  ViewController.swift
//  stack
//
//  Created by Katie  Lee on 7/4/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var winnerLabel: UILabel!
    @IBOutlet var allTTTButton: [UIButton]!
    var player_one = true
    var winningcombos = [
        [1,2,3],[4,5,6],[7,8,9],[1,5,9],
        [3,5,7],[1,4,7],[2,5,8],[3,6,9]
    ]
    var player_one_moves = [Int]()
    var player_two_moves = [Int]()
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        if sender.backgroundColor == UIColor.lightGray {
            if player_one{
                player_one_moves.append(sender.tag)
                player_one = false
                sender.backgroundColor = UIColor.red
                if isWinningMove(which_player_move: player_one_moves) {
                    winnerLabel.text = "Congrats Red Won"
                }
            }
            else{
                player_two_moves.append(sender.tag)
                player_one = true
                sender.backgroundColor = UIColor.blue
                if isWinningMove(which_player_move: player_two_moves) {
                    winnerLabel.text = "Congrats Blue Won"
                }
            }
        }
    }
    
    @IBAction func resetbuttonPressed(_ sender: UIButton) {
        for i in allTTTButton {
            i.backgroundColor = UIColor.lightGray
        }
        player_one_moves = []
        player_two_moves = []
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for i in allTTTButton {
            i.backgroundColor = UIColor.lightGray
        }
    }
    
    
    func isWinningMove(which_player_move:[Int])->Bool {
        let biggerlist = Set(which_player_move)
        for i in winningcombos {
            let combo = Set(i)
            if combo.isSubset(of: biggerlist) {
                return true
            }
        }
        return false
    }




}

