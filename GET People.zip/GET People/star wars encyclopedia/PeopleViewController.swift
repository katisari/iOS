//
//  PeopleViewController.swift
//  star wars encyclopedia
//
//  Created by Katie  Lee on 7/16/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class PeopleViewController: UITableViewController {
    var people: [NSDictionary] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        getData(from: "http://swapi.co/api/people")
    }
    
    func getData(from url: String) {
        let url = URL(string: url)
        let session = URLSession.shared
        let task = session.dataTask(with: url!, completionHandler: {
            // see: Swift closure expression syntax
            data, response, error in
            do {
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
                    if let results = jsonResult["results"] as? [NSDictionary]{
                        self.people.append(contentsOf: results)
                        DispatchQueue.main.sync {
                            self.tableView.reloadData()
                        }
                        if let nexturl = jsonResult["next"] as? String {
                            self.getData(from: nexturl)
                        }
                        
                    }
                }
            } catch {
                print(error)
            }
        })
        task.resume()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return people.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = people[indexPath.row]["name"] as? String
        return cell
    }

}
