//
//  ViewController.swift
//  cold_call
//
//  Created by Katie  Lee on 7/3/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var numLabel: UILabel!
    
    let name_bank = [
        "Ready?",
        "Katie",
        "James",
        "Jimmy",
        "Possible",
        "Jane"
    ]
    var currentPerson = 0
    @IBAction func coldcallButtonPressed(_ sender: UIButton) {
        currentPerson = Int(arc4random_uniform(5))+1
        updateUI()
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }

    func updateUI(){
        nameLabel.text = name_bank[currentPerson]
        numLabel.text = String(currentPerson)
        if currentPerson == 1 || currentPerson == 2 {
            numLabel.textColor = UIColor.red
        } else if currentPerson == 3 || currentPerson == 4 {
            numLabel.textColor = UIColor.orange
        }
        else if currentPerson == 5{
            numLabel.textColor = UIColor.green
        }
        
    }


}

