//
//  AddItemTVCDelegate.swift
//  bucket_list
//
//  Created by Katie  Lee on 7/10/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import Foundation
protocol AddItemTVCDelegate: class {
    func itemSaved(by controller: AddItemTableViewController, with text: String, at indexPath: NSIndexPath?)
    func cancelButtonPressed(by controller: AddItemTableViewController)
}
