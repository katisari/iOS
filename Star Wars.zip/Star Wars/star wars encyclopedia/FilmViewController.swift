//
//  FilmViewController.swift
//  star wars encyclopedia
//
//  Created by Katie  Lee on 7/16/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class FilmViewController: UITableViewController {
    var films: [NSDictionary] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        getData(from: "https://swapi.co/api/films/")
    }
    
    func getData(from url: String) {
        let url = URL(string: url)
        let session = URLSession.shared
        let task = session.dataTask(with: url!, completionHandler: {
            // see: Swift closure expression syntax
            data, response, error in
            do {
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
                    if let results = jsonResult["results"] as? [NSDictionary]{
                        self.films.append(contentsOf: results)
                        DispatchQueue.main.sync {
                            self.tableView.reloadData()
                        }
                    }
                }
            } catch {
                print(error)
            }
        })
        task.resume()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return films.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "filmCell", for: indexPath)
        cell.textLabel?.text = films[indexPath.row]["title"] as? String
        return cell
    }

}
