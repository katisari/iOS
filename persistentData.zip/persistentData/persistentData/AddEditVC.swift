//
//  AddEditVC.swift
//  persistentData
//
//  Created by Katie  Lee on 7/11/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class AddEditVC: UIViewController {

    @IBOutlet weak var nameTextLabel: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
    var user: User?
    override func viewDidLoad() {
        super.viewDidLoad()
        if let userr = user {
            nameTextLabel.text = userr.name
            ageTextField.text = "\(userr.age)"
        }
    }

    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveButtonPressed(_ sender: UIBarButtonItem) {
        performSegue(withIdentifier: "unwindSegueVC", sender: sender)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

}
