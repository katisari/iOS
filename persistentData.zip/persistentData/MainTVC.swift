//
//  MainTVC.swift
//  persistentData
//
//  Created by Katie  Lee on 7/11/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit
import CoreData

class MainTVC: UITableViewController {
    
    
    @IBOutlet var table: UITableView!
    
    let appdelegate = UIApplication.shared.delegate as! AppDelegate
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var tableData: [User] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
        fetchAllUser()
    }
    
    func fetchAllUser() {
        let req:NSFetchRequest<User> = User.fetchRequest()
        do {
            tableData = try context.fetch(req)
            // Here we can store the fetched data in an array
        } catch {
            print(error)
        }
    }


    @IBAction func PlusButtonPressed(_ sender: UIBarButtonItem) {
        performSegue(withIdentifier: "PlusSegue", sender: sender)
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "PlusSegue", sender: indexPath)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("HALLOOO")
        if let sending = sender as? IndexPath {
            let nav = segue.destination as! UINavigationController
            let dest = nav.topViewController as! AddEditVC
            
            let user = tableData[sending.row]
            dest.user = user
        }
    }
    @IBAction func unwindToVC(segue:UIStoryboardSegue) {
        let src = segue.source as! AddEditVC
        let name = src.nameTextLabel.text
        let age = src.ageTextField.text!
        if let theuser = src.user {
            theuser.name = name
            if let age = Int16(age) {
                theuser.age = age
            }
            
        } else {
            let newUser = User(context: context)
            newUser.name = name
            if let age = Int16(age) {
                newUser.age = age
            } else {
                newUser.age = 0
            }
            
            tableData.append(newUser)
            
        }
        appdelegate.saveContext()
        table.reloadData()
    }
   

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        let user = tableData[indexPath.row]
        cell.textLabel?.text = user.name
        cell.detailTextLabel?.text = "\(user.age)"
        return cell
    }
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete", handler: {action, view, done in
//            self.deleteObject(indexPath: indexPath)
            self.context.delete(self.tableData[indexPath.row])
            self.tableData.remove(at: indexPath.row)
            self.appdelegate.saveContext()
            tableView.reloadData()
//            done(true)
        })
//        table.deleteRows(at: [indexPath], with: .automatic)
      
        deleteAction.backgroundColor = .red
        let configuration = UISwipeActionsConfiguration(actions: [deleteAction])
        return configuration

    }
    
    func deleteObject(indexPath: IndexPath) {
        let user = tableData[indexPath.row]
        context.delete(user)
        appdelegate.saveContext()
    }
}
