//
//  OtherViewController.swift
//  direction
//
//  Created by Katie  Lee on 7/9/18.
//  Copyright © 2018 Katie  Lee. All rights reserved.
//

import UIKit

class OtherViewController: UIViewController {
    @IBOutlet weak var outputLabel: UILabel!
    var output: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        outputLabel.text = output
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func backButtonPressed(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    

}
